try:
    arquivo = open('emials.txt', 'w')
except FileNotFoundError:
    print('Arquivo nâo existe')