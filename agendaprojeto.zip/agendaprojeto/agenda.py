AGENDA = {
    'guilherme': {
        'telefone': '7854965426',
        'email': 'guilherme@gmmail.com',
        'endereco': 'Av 1',
    },

    'maria': {
        'telefone': '75846957',
        'email': 'maria@gmailcom',
        'endereco': 'Av 2',
    },

    'joao': {
        'telefone': '5744888',
        'email': 'joao@gmail.com',
        'endereco': 'Av 3',
    },
}


def mostar_contatos():
    for contato in AGENDA:
        buscar_contato(contato)


def buscar_contato(contato):
    try:
        print('Nome: ', contato)
        print('Telefone:', AGENDA[contato]['telefone'])
        print('Email:', AGENDA[contato]['email'])
        print('Endereço:', AGENDA[contato]['endereco'])
        print('===========================')
    except KeyError:
        print('>>>>>> Contato nâo existe na agenda <<<<<<')

def adcionar_contato(contato, telefone, email, endereco):
    AGENDA[contato] = {
        'telefone': telefone,
        'email': email,
        'endereco': endereco,
     }
    print('>>>>>> {} adicionado/editado com sucesso!! <<<<<<'.format(contato))

def editar_contato(contato, telefone, email, endereco):
    adcionar_contato(contato, telefone, email, endereco)

def remover_contatos(contato):
    try:
        AGENDA.pop(contato)
        print('>>>>>> {} excluido com sucesso!! <<<<<<'.format(contato))
        mostar_contatos()
    except KeyError:
        print('>>>>>> O contato informado não existe na agenda.<<<<<<')
    except Exception as erro:
        log = erro

def exportar_contatos():
    try:
        with open('agenda.csv', 'w') as arquivo:
            for contato in AGENDA:
                telefone = AGENDA[contato]['telefone']
                email = AGENDA[contato]['email']
                endereco = AGENDA[contato]['endereco']
                arquivo.write('{};{};{};{}\n'.format(contato, telefone, email, endereco))
        print('>>>>>> Agenda exportada com sucesso!')
    except Exception as erro:
        print('Algum erro aconteceu!')
        print(erro)

def mostrar_menu():
    print('1 - Mostrar todos os contatos da AGENDA.')
    print('2 - Buscar contatos.')
    print('3 - Adcionar contato.')
    print('4 - Editar contato.')
    print('5 - Excluir contato.')
    print('6 - Exportar contatos CSV')
    print('0 - sair do programa.')



while True:
    mostrar_menu()
    op = input('Dgite a opção: ')
    if op == '1':
        mostar_contatos()
    elif op == '2':
        contato = input('Digite o nome do contato que deseja buscar: ')
        buscar_contato(contato)
    elif op == '3':
        contato = input('Digite o nome do contato: ')
        try:
            AGENDA[contato]
            print('>>>>> O contato: ', contato, ' já existe!')
            continue
        except:
            print('>>>>> Adicionando contato: ', contato)
            telefone = input('Digite o telefone do contato: ')
            email = input('Digite o email do contato: ')
            endereco = input('Digite o endereço do contato: ')
            adcionar_contato('contato', 'telefone', 'email', 'endereco')
    elif op == '4':
        try:
            contato = input('Digite o nome do contato: ')
            AGENDA[contato]
            print('>>>>>> Editando contato: ', contato)
            telefone = input('Digite o telefone do contato: ')
            email = input('Digite o email do contato: ')
            endereco = input('Digite o endereço do contato: ')
            editar_contato('contato', 'telefone', 'email', 'endereco')
        except KeyError:
            print('O contato: ', contato, ' não existe na agenda!')
            continue
    elif op == '5':
        contato = input('Digite o nome do contato que deseja excluir: ')
        remover_contatos(contato)
    elif op == '6':
        exportar_contatos()
        continue
    elif op == '0':
        print('O progama fechou!')
        break
    else:
        print('Opção Invalida!!')

