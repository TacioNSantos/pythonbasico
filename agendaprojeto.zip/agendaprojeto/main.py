minha_lista = ['azul' , 'vermelho', 'amarelo']
print(minha_lista)

minha_lista.append('roxo')
# minha_lista.clear()
minha_lista.remove('azul')

for cor in minha_lista:
    print(minha_lista)

print(minha_lista[2])
