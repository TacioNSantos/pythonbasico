try:
    with open('nomes.txt', 'a') as arquivo:
        arquivo.write('joao\n')
except Exception as erro:
    print('Algum erro aconteceu')
    print(erro)

# r - leitura
# w - escrita / sobrescrever
# a - escrever/ adicionar sem sobrescrever
# \n - pula linha
# + cria o arquivo
# b lê em binario