cont = 0
while cont <= 10:
    print('volta de número: {}'.format(cont))
    cont = cont + 1